# Style Guide

Display font: Open Sans
Paragraph font: Crimson text

Highlight color: #5EBD91
Text color: #000000
Accent color: #FBF6F6

Logo font size: 27px
Logo font weight: 800

Navbar font size: 18px
Navbar font weight: 600

Display font size: 45px
Display font weight: 800
Display line height: 49px

Section header font size: 35px
Section header font weight: 800

Project title font size: 30px
Project title font weight: 800
Project description font size: 17px
Project description line height: 25px

development plan:

1. Style the main structure of the website
  a. fix the navbar
  b. position the copy
  c. fix the icons
  d. position project images and their descriptions
    d.1 try to use flex only if i can
  e. fix the footer
    e.1 add the line 

2. add the main styles
  a. add the highlights in my Logo
    a.1 color the "me" in the navbar
  b. think of a way to achieve the green bars or highlights